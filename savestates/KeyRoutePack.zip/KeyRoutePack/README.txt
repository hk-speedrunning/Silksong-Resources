# KeyMist Training Pack

This pack contains **savestates for training KeyMist** and a set of **LiveSplit files to practice ILs**.

## Savestate Details

- **Pages 1–3:** ComSobs ILs  
- **Pages 3–5:** Movements (tricky rooms)  
- **Pages 5–6:** Tricks  
- **Pages 7–9:** Bosses & Arena Fights  
- **Pages 10–13:** Mists  

## Installation

Paste the **Savestates 1.0** folder here: (replace [USER] with your user folder)

```
C:\Users\[USER]\AppData\LocalLow\Team Cherry\Hollow Knight Silksong\DebugModData
```

## Note

The folder exceeds the default savestate page limit (**13 pages instead of 10**).

To change it, edit this file:

```
C:\Users\[USER]\AppData\LocalLow\Team Cherry\Hollow Knight Silksong\DebugModData\Settings.json
```

Replace:

```json
"MaxSavePages": 10
```

with:

```json
"MaxSavePages": 15
```

(or any number you feel comfortable with).